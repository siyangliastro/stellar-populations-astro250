"""
IMF Power-Law Precision Analysis
Astro 250 Spring 2026
Solving problems on measuring the Initial Mass Function slope precision
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from scipy.optimize import minimize
import pandas as pd

# Set random seed for reproducibility
np.random.seed(42)

# ============================================================================
# PROBLEM 1: ANALYTIC APPROXIMATION OF PRECISION
# ============================================================================

def analytic_precision(N, R, alpha=2.35):
    """
    Derive analytic approximation for the uncertainty in measuring alpha.
    
    For a power-law distribution dN/dM ∝ M^(-alpha), the uncertainty
    in the slope can be approximated using Fisher information theory.
    
    The standard error scales as:
    σ_α ≈ sqrt(variance) where variance comes from the curvature of the
    log-likelihood function.
    
    For a power-law with bounds [M_min, M_max]:
    - The Fisher Information is proportional to N and to the leverage 
      provided by the mass range
    - σ_α ∝ 1/sqrt(N) from counting statistics
    - σ_α ∝ 1/log(R) from the dynamic range (lever arm effect)
    
    Parameters:
    -----------
    N : int
        Number of stars
    R : float
        Dynamic mass range (M_max/M_min)
    alpha : float
        Power-law slope (default 2.35 for Salpeter IMF)
    
    Returns:
    --------
    sigma_alpha : float
        Uncertainty in alpha measurement
    """
    
    # The analytic approximation comes from considering:
    # 1. Statistical uncertainty scales as 1/sqrt(N)
    # 2. Leverage from mass range scales as 1/ln(R)
    # 3. For a power-law, there's an additional factor involving alpha
    
    # From maximum likelihood estimation theory for power-laws:
    # The variance of the MLE estimator is:
    # Var(α̂) ≈ (α-1)^2 / (N * ln(R)^2)
    
    # This is valid when α > 1 and R >> 1
    
    if alpha <= 1:
        # For alpha close to or less than 1, the distribution is very steep
        # and the approximation breaks down
        alpha_eff = 1.5  # Use effective value
    else:
        alpha_eff = alpha
    
    if R <= 1:
        return np.inf
    
    # Standard approximation
    sigma_alpha = (alpha_eff - 1) / (np.sqrt(N) * np.log(R))
    
    return sigma_alpha


def analytic_precision_improved(N, R, alpha=2.35):
    """
    Improved analytic approximation including higher-order corrections.
    
    This accounts for:
    - Finite sample effects
    - Bias corrections for small N
    - Edge effects from bounded distribution
    """
    
    if R <= 1 or N < 3:
        return np.inf
    
    # Base calculation
    base_sigma = (alpha - 1) / (np.sqrt(N) * np.log(R))
    
    # Correction factor for finite N (increases uncertainty for small N)
    finite_N_correction = np.sqrt(1 + 2.0/N)
    
    # Correction for bounded domain (reduces leverage when R is small)
    if R < 10:
        range_correction = 1.0 + 1.0/(np.log(R) + 1)
    else:
        range_correction = 1.0
    
    sigma_alpha = base_sigma * finite_N_correction * range_correction
    
    return sigma_alpha


# ============================================================================
# PROBLEM 2: MONTE CARLO VERIFICATION
# ============================================================================

def generate_power_law_sample(N, alpha, M_min, M_max):
    """
    Generate N stellar masses from a power-law distribution.
    
    For dN/dM ∝ M^(-alpha), we use inverse transform sampling:
    
    CDF: F(M) = [M^(1-α) - M_min^(1-α)] / [M_max^(1-α) - M_min^(1-α)]
    
    Inverse: M = [u * (M_max^(1-α) - M_min^(1-α)) + M_min^(1-α)]^(1/(1-α))
    where u ~ Uniform(0,1)
    
    Parameters:
    -----------
    N : int
        Number of stars to generate
    alpha : float
        Power-law slope
    M_min, M_max : float
        Minimum and maximum stellar mass
    
    Returns:
    --------
    masses : array
        Array of N stellar masses
    """
    
    u = np.random.uniform(0, 1, N)
    
    if np.abs(alpha - 1.0) < 1e-6:
        # Special case: α = 1, logarithmic distribution
        masses = M_min * np.exp(u * np.log(M_max / M_min))
    else:
        # General case
        exp = 1 - alpha
        M_min_exp = M_min ** exp
        M_max_exp = M_max ** exp
        
        masses = (u * (M_max_exp - M_min_exp) + M_min_exp) ** (1.0 / exp)
    
    return masses


def fit_power_law_mle(masses, M_min, M_max):
    """
    Fit power-law to mass sample using Maximum Likelihood Estimation.
    
    For a power-law dN/dM ∝ M^(-α) on [M_min, M_max]:
    
    Log-likelihood: L = Σ ln[p(M_i)]
    where p(M) = (α-1) * M^(-α) / [M_min^(1-α) - M_max^(1-α)]
    
    The MLE estimator for α is found by maximizing L.
    
    Returns:
    --------
    alpha_fit : float
        Best-fit power-law slope
    alpha_err : float
        Uncertainty estimate from Fisher information
    """
    
    N = len(masses)
    
    # Negative log-likelihood to minimize
    def neg_log_likelihood(alpha):
        if alpha <= 1.0 or alpha > 10:
            return 1e10
        
        # Normalization constant
        exp = 1 - alpha
        norm = (M_min ** exp - M_max ** exp) / exp
        
        # Log-likelihood
        log_p = np.log(alpha - 1) - alpha * np.log(masses) - np.log(np.abs(norm))
        return -np.sum(log_p)
    
    # Find MLE
    result = minimize(neg_log_likelihood, x0=2.5, method='Nelder-Mead',
                     options={'xatol': 1e-6, 'fatol': 1e-6})
    
    alpha_fit = result.x[0]
    
    # Estimate uncertainty from Fisher information
    # Var(α̂) ≈ 1/I(α) where I(α) is Fisher information
    # For our case: σ_α ≈ (α-1) / sqrt(N * ln(R)^2)
    R = M_max / M_min
    alpha_err = analytic_precision(N, R, alpha_fit)
    
    return alpha_fit, alpha_err


def monte_carlo_simulation(N, alpha_true, M_min, M_max, n_realizations=500):
    """
    Run Monte Carlo simulation to measure precision in recovering alpha.
    
    Parameters:
    -----------
    N : int
        Number of stars per realization
    alpha_true : float
        True power-law slope
    M_min, M_max : float
        Mass range
    n_realizations : int
        Number of independent realizations
    
    Returns:
    --------
    alpha_fits : array
        Best-fit alpha values from all realizations
    alpha_errs : array
        Estimated uncertainties from all realizations
    """
    
    alpha_fits = np.zeros(n_realizations)
    alpha_errs = np.zeros(n_realizations)
    
    for i in range(n_realizations):
        # Generate synthetic data
        masses = generate_power_law_sample(N, alpha_true, M_min, M_max)
        
        # Fit the data
        alpha_fit, alpha_err = fit_power_law_mle(masses, M_min, M_max)
        
        alpha_fits[i] = alpha_fit
        alpha_errs[i] = alpha_err
    
    return alpha_fits, alpha_errs


def run_parameter_study():
    """
    Run Monte Carlo simulations varying N and R to build statistical profile.
    """
    
    # Parameters to vary
    N_values = [50, 100, 200, 500, 1000, 2000]
    R_values = [5, 10, 20, 50, 100]  # M_max/M_min
    
    alpha_true = 2.35  # Salpeter IMF
    M_min = 0.1  # Solar masses
    n_realizations = 500
    
    results = []
    
    print("Running parameter study...")
    print(f"True alpha = {alpha_true}")
    print(f"N values: {N_values}")
    print(f"R values: {R_values}")
    print(f"Realizations per configuration: {n_realizations}\n")
    
    for R in R_values:
        M_max = R * M_min
        
        for N in N_values:
            print(f"Running N={N}, R={R:.0f}...", end=" ")
            
            # Monte Carlo simulation
            alpha_fits, alpha_errs = monte_carlo_simulation(
                N, alpha_true, M_min, M_max, n_realizations
            )
            
            # Compute statistics
            measured_sigma = np.std(alpha_fits)
            median_predicted_err = np.median(alpha_errs)
            bias = np.mean(alpha_fits) - alpha_true
            
            # Analytic prediction
            analytic_sigma = analytic_precision(N, R, alpha_true)
            analytic_sigma_improved = analytic_precision_improved(N, R, alpha_true)
            
            results.append({
                'N': N,
                'R': R,
                'M_min': M_min,
                'M_max': M_max,
                'measured_sigma': measured_sigma,
                'median_predicted_err': median_predicted_err,
                'analytic_sigma': analytic_sigma,
                'analytic_sigma_improved': analytic_sigma_improved,
                'bias': bias,
                'alpha_fits': alpha_fits
            })
            
            print(f"σ_measured={measured_sigma:.4f}, σ_analytic={analytic_sigma:.4f}")
    
    return pd.DataFrame(results)


# ============================================================================
# PLOTTING FUNCTIONS
# ============================================================================

def plot_monte_carlo_results(results_df):
    """Create comprehensive plots of Monte Carlo results."""
    
    fig, axes = plt.subplots(2, 2, figsize=(14, 12))
    
    # Plot 1: Measured vs Analytic Precision (varying N)
    ax = axes[0, 0]
    for R in results_df['R'].unique():
        data = results_df[results_df['R'] == R]
        ax.loglog(data['N'], data['measured_sigma'], 'o-', label=f'R={R:.0f} (Measured)', markersize=6)
        ax.loglog(data['N'], data['analytic_sigma'], '--', alpha=0.7)
    
    # Add scaling reference lines
    N_ref = np.array([50, 2000])
    ax.loglog(N_ref, 0.5 * N_ref**(-0.5), 'k:', linewidth=2, label=r'$\propto N^{-1/2}$')
    
    ax.set_xlabel('Number of Stars (N)', fontsize=12)
    ax.set_ylabel(r'Precision in $\alpha$ ($\sigma_\alpha$)', fontsize=12)
    ax.set_title('Precision vs Sample Size (varying R)', fontsize=13, fontweight='bold')
    ax.legend(fontsize=9, ncol=2)
    ax.grid(True, alpha=0.3)
    
    # Plot 2: Measured vs Analytic Precision (varying R)
    ax = axes[0, 1]
    for N in [100, 500, 1000]:
        data = results_df[results_df['N'] == N]
        if len(data) > 0:
            ax.plot(data['R'], data['measured_sigma'], 'o-', label=f'N={N} (Measured)', markersize=6)
            ax.plot(data['R'], data['analytic_sigma'], '--', alpha=0.7)
    
    ax.set_xlabel('Mass Range (R = M_max/M_min)', fontsize=12)
    ax.set_ylabel(r'Precision in $\alpha$ ($\sigma_\alpha$)', fontsize=12)
    ax.set_title('Precision vs Mass Range (varying N)', fontsize=13, fontweight='bold')
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3)
    ax.set_xscale('log')
    ax.set_yscale('log')
    
    # Plot 3: Comparison of measured to analytic (1:1 plot)
    ax = axes[1, 0]
    ax.scatter(results_df['analytic_sigma'], results_df['measured_sigma'], 
              c=np.log10(results_df['N']), cmap='viridis', s=80, alpha=0.7, edgecolors='k', linewidths=0.5)
    
    # 1:1 line
    lim = [results_df[['analytic_sigma', 'measured_sigma']].min().min() * 0.8,
           results_df[['analytic_sigma', 'measured_sigma']].max().max() * 1.2]
    ax.plot(lim, lim, 'r--', linewidth=2, label='1:1 line')
    
    # ±20% lines
    ax.fill_between(lim, np.array(lim)*0.8, np.array(lim)*1.2, alpha=0.2, color='gray', label='±20%')
    
    ax.set_xlabel(r'Analytic Prediction $\sigma_\alpha$', fontsize=12)
    ax.set_ylabel(r'Measured $\sigma_\alpha$ (Monte Carlo)', fontsize=12)
    ax.set_title('Analytic vs Measured Precision', fontsize=13, fontweight='bold')
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3)
    ax.set_xscale('log')
    ax.set_yscale('log')
    
    cbar = plt.colorbar(ax.collections[0], ax=ax)
    cbar.set_label('log₁₀(N)', fontsize=11)
    
    # Plot 4: Example distribution of recovered alphas
    ax = axes[1, 1]
    example_data = results_df[(results_df['N'] == 500) & (results_df['R'] == 20)].iloc[0]
    
    ax.hist(example_data['alpha_fits'], bins=30, density=True, alpha=0.7, 
           edgecolor='black', label='MC Realizations')
    
    # Overlay Gaussian with measured sigma
    alpha_true = 2.35
    x = np.linspace(example_data['alpha_fits'].min(), example_data['alpha_fits'].max(), 100)
    gaussian = stats.norm.pdf(x, loc=alpha_true, scale=example_data['measured_sigma'])
    ax.plot(x, gaussian, 'r-', linewidth=2, label=f'Gaussian (σ={example_data["measured_sigma"]:.3f})')
    
    ax.axvline(alpha_true, color='k', linestyle='--', linewidth=2, label=f'True α={alpha_true}')
    ax.set_xlabel(r'Recovered $\alpha$', fontsize=12)
    ax.set_ylabel('Probability Density', fontsize=12)
    ax.set_title(f'Distribution of Recovered α (N={example_data["N"]}, R={example_data["R"]:.0f})', 
                fontsize=13, fontweight='bold')
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    return fig


def plot_scaling_laws(results_df):
    """Plot scaling laws to verify N^(-1/2) and 1/ln(R) behavior."""
    
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    # Plot 1: Test N^(-1/2) scaling
    ax = axes[0]
    R_test = 20
    data = results_df[results_df['R'] == R_test].sort_values('N')
    
    # Plot measured sigma vs N^(-1/2)
    ax.plot(data['N']**(-0.5), data['measured_sigma'], 'o-', markersize=8, 
           linewidth=2, label='Measured', color='blue')
    ax.plot(data['N']**(-0.5), data['analytic_sigma'], 's--', markersize=7, 
           linewidth=2, label='Analytic', color='red', alpha=0.7)
    
    # Fit line to verify scaling
    from scipy.stats import linregress
    slope, intercept, r_value, _, _ = linregress(data['N']**(-0.5), data['measured_sigma'])
    ax.plot(data['N']**(-0.5), slope * data['N']**(-0.5) + intercept, 
           'k:', linewidth=2, label=f'Linear fit (R²={r_value**2:.4f})')
    
    ax.set_xlabel(r'$N^{-1/2}$', fontsize=13)
    ax.set_ylabel(r'$\sigma_\alpha$', fontsize=13)
    ax.set_title(f'Verification of $N^{{-1/2}}$ Scaling (R={R_test})', 
                fontsize=13, fontweight='bold')
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    
    # Plot 2: Test 1/ln(R) scaling
    ax = axes[1]
    N_test = 500
    data = results_df[results_df['N'] == N_test].sort_values('R')
    
    # Plot measured sigma vs 1/ln(R)
    ax.plot(1/np.log(data['R']), data['measured_sigma'], 'o-', markersize=8, 
           linewidth=2, label='Measured', color='blue')
    ax.plot(1/np.log(data['R']), data['analytic_sigma'], 's--', markersize=7, 
           linewidth=2, label='Analytic', color='red', alpha=0.7)
    
    # Fit line to verify scaling
    slope, intercept, r_value, _, _ = linregress(1/np.log(data['R']), data['measured_sigma'])
    ax.plot(1/np.log(data['R']), slope * 1/np.log(data['R']) + intercept, 
           'k:', linewidth=2, label=f'Linear fit (R²={r_value**2:.4f})')
    
    ax.set_xlabel(r'$1 / \ln(R)$', fontsize=13)
    ax.set_ylabel(r'$\sigma_\alpha$', fontsize=13)
    ax.set_title(f'Verification of $1/\ln(R)$ Scaling (N={N_test})', 
                fontsize=13, fontweight='bold')
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    return fig


if __name__ == "__main__":
    # Run the parameter study
    print("="*70)
    print("IMF POWER-LAW PRECISION ANALYSIS")
    print("="*70 + "\n")
    
    results_df = run_parameter_study()
    
    # Save results
    results_df.to_pickle('/home/claude/mc_results.pkl')
    
    # Create plots
    print("\nGenerating plots...")
    
    fig1 = plot_monte_carlo_results(results_df)
    fig1.savefig('/home/claude/mc_results.png', dpi=300, bbox_inches='tight')
    print("Saved: mc_results.png")
    
    fig2 = plot_scaling_laws(results_df)
    fig2.savefig('/home/claude/scaling_laws.png', dpi=300, bbox_inches='tight')
    print("Saved: scaling_laws.png")
    
    # Print summary statistics
    print("\n" + "="*70)
    print("SUMMARY STATISTICS")
    print("="*70)
    print("\nComparison of Analytic vs Measured Precision:")
    print(results_df[['N', 'R', 'measured_sigma', 'analytic_sigma', 'bias']].to_string(index=False))
    
    # Calculate agreement metrics
    ratio = results_df['measured_sigma'] / results_df['analytic_sigma']
    print(f"\nAnalytic/Measured Ratio:")
    print(f"  Mean: {ratio.mean():.3f}")
    print(f"  Std:  {ratio.std():.3f}")
    print(f"  Min:  {ratio.min():.3f}")
    print(f"  Max:  {ratio.max():.3f}")
    
    plt.close('all')
